const mongoose = require ('mongoose')

 const Post = require('./models/Post')

 mongoose.connect('mongodb://127.0.0.1/siteyapimi_db',  {
     useNewUrlParser: true, 
     useUnifiedTopology : true
 })

 Post.create({
     title : 'benim ilk baslıgım ', 
     content : 'lorem ipsum dolor sit aamet'
 } , (error , post) => {
     console.log(error, post)
 })