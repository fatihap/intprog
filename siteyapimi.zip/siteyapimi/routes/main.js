const express = require('express')
const res = require('express/lib/response')
const router = express.Router()
const Post = require('../models/Post')

router.get('/', (req, res)=>{
    res.render('site/index')
})

router.get('/about', (req, res)=>{
    res.render('site/about')
})
router.get('/blog', (req , res) => {
    Post.find({}).then(posts =>{
        res.render('/site/blog', {posts: posts})
    })
})
router.get('/bitenprojeler', (req, res)=>{
    res.render('site/bitenproje')
})
router.get('/emlak', (req, res)=>{
    res.render('site/emlak')
})
router.get('/hafriyat', (req, res)=>{
    res.render('site/hafriyat')
})
router.get('/iletisim', (req, res)=>{
    res.render('site/iletisim')
})
router.get('/katkarsiligiinsaat', (req, res)=>{
    res.render('site/katkarsiligi')
})
router.get('/devamedenprojeler', (req, res)=>{
    res.render('site/projelerimiz')
})
router.get('/tadilat', (req, res)=>{
    res.render('site/tadilat')
})
router.get('/login', (req, res)=>{
    res.render('site/login')
})
router.get('/register', (req, res)=>{
    res.render('site/register')
})
router.get('/newpost', (req, res)=>{
    res.render('site/addpost')
})
router.post('/posts/test' ,(req, res)=>{
    console.log(req.body)
    res.redirect('/')

})


module.exports = router