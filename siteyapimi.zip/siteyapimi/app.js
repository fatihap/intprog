const path = require('path')
const express = require('express')
const exphbs = require('express-handlebars')
const req = require('express/lib/request')
const res = require('express/lib/response')
const app = express()
const port = 3000
const hostname = '127.0.0.1'


const mongoose = require('mongoose')
var bodyParser = require('body-parser') 

mongoose.connect('mongodb://127.0.0.1/siteyapimi_db',{
    useNewUrlParser:true,
    useUnifiedTopology:true
})

const { application } = require('express')

app.use(express.static('public'))

app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())

const main = require ('./routes/main')
const posts = require('./routes/posts')
app.use('/', main )
app.use('/posts', posts)


app.listen(port, () => {
    console.log(`Server Calisiyor ,  http://${hostname}:${port}/` )
})